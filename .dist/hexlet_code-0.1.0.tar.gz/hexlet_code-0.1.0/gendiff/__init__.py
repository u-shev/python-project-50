from gendiff.engine import generate_diff  # noqa: F401
from gendiff.parser import parser

__all__ = ('generate_diff',
        'parser',)
